#!/bin/bash

# 确保脚本以root权限运行
if [ "$(id -u)" != "0" ]; then
    echo "这个脚本需要以root权限运行。"
    exit 1
fi

# 检查/etc/ZE15_do.sh是否存在
if [ ! -f /etc/ZE15_do.sh ]; then
    echo "文件 /etc/ZE15_do.sh 不存在。"
    exit 1
fi

# 确保/etc/ZE15_do.sh可执行
chmod +x /etc/ZE15_do.sh

# 检查systemctl命令是否存在
if command -v systemctl > /dev/null; then
    # 使用Systemd
    echo "[Unit]
Description=Run ZE15_do.sh at Startup

[Service]
ExecStart=/etc/ZE15_do.sh
Type=forking

[Install]
WantedBy=multi-user.target" > /etc/systemd/system/ZE15.service

    # 启用并启动服�
    systemctl daemon-reload
    systemctl enable ZE15.service
    systemctl start ZE15.service
else
    # 使用传统的init
    # 检查/etc/rc.local或/etc/rc.d/rc.local是否存在
    RC_LOCAL_PATH=""
    if [ -f /etc/rc.local ]; then
        RC_LOCAL_PATH="/etc/rc.local"
    elif [ -f /etc/rc.d/rc.local ]; then
        RC_LOCAL_PATH="/etc/rc.d/rc.local"
    else
        echo "未找到rc.local文件。"
        exit 1
    fi

    # 将命令添加到rc.local
    echo "/etc/ZE15_do.sh" >> "$RC_LOCAL_PATH"
fi

echo "配置完成。"

